const http = require("http");
const fs = require("fs");
const querystring = require("querystring");

const server = http.createServer((req, res) => {
  if (req.method === "POST") {
    let body = "";

    req.on("data", (chunk) => {
      body += chunk;
    });

    req.on("end", () => {
      const formData = querystring.parse(body);
      const fullName = formData["Name"];
      const email = formData["email"];
      const password = formData["password"];
      const conPassword = formData["con_password"];

      // Create a new file and write the form data to it
      fs.writeFile(
        "output.txt",
        `Full Name: ${fullName}\nEmail: ${email}\nPassword: ${password}\nConfirm Password: ${conPassword}`,
        (err) => {
          if (err) {
            console.error(err);
            res.writeHead(500, { "Content-Type": "text/plain" });
            res.end("Internal Server Error");
          } else {
            res.writeHead(200, { "Content-Type": "text/html" });
            res.end("<h1>Form data saved successfully!</h1>");
          }
        }
      );
    });
  }
});

server.listen(4000, () => {
  console.log("Server is running on port 3000");
});
